// Create the reference variable of the canvas using fabric.Canvas()


// Define the starting width and height of the block images



// Define the starting x and y coordinates for the player



// Define a variable named player_object to store object of the player image


// Add a function named player_update() to add the player image







// Add a function named new_image() to add the different images as per the specific keys pressed

